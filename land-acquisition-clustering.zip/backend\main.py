"""
FastAPI Backend for Land Acquisition Delay Pattern Segmentation (LACPS).
Serves the ML pipeline results via REST API.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
import json
import time

from ml.pipeline import run_full_pipeline, CLUSTERING_FEATURES
from ml.data_generator import generate_land_acquisition_dataset, get_feature_descriptions

app = FastAPI(
    title="LACPS API",
    description="Land Acquisition Clustering Pattern Segmentation — ML Pipeline API",
    version="1.0.0",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Cache results in memory
_cache = {}


class AnalysisRequest(BaseModel):
    n_samples: int = 2000
    force_refresh: bool = False


@app.get("/")
async def root():
    return {"message": "LACPS API — Land Acquisition Clustering Pattern Segmentation", "status": "active"}


@app.get("/api/health")
async def health():
    return {"status": "healthy", "timestamp": time.time()}


@app.get("/api/features")
async def get_features():
    """Return feature list and descriptions."""
    return {
        "clustering_features": CLUSTERING_FEATURES,
        "descriptions": get_feature_descriptions(),
    }


@app.post("/api/analyze")
async def analyze(request: AnalysisRequest):
    """Run full clustering analysis pipeline."""
    cache_key = f"analysis_{request.n_samples}"
    
    if cache_key in _cache and not request.force_refresh:
        return _cache[cache_key]
    
    try:
        start = time.time()
        results = run_full_pipeline(n_samples=request.n_samples)
        elapsed = round(time.time() - start, 2)
        
        results['meta'] = {
            'computation_time_seconds': elapsed,
            'n_samples': request.n_samples,
            'timestamp': time.time(),
        }
        
        # Sample PCA scatter for frontend performance (max 800 points)
        if len(results.get('pca_scatter', [])) > 800:
            import random
            random.seed(42)
            results['pca_scatter'] = random.sample(results['pca_scatter'], 800)
        
        _cache[cache_key] = results
        return results
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/dataset-preview")
async def dataset_preview():
    """Return a small preview of the generated dataset."""
    df = generate_land_acquisition_dataset(n_samples=100)
    return {
        "columns": list(df.columns),
        "data": json.loads(df.head(20).to_json(orient='records')),
        "shape": list(df.shape),
        "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
