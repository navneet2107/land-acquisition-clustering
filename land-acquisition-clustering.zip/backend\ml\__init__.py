# ML Pipeline modules for Land Acquisition Delay Pattern Segmentation
