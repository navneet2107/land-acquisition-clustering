import React from 'react';
import { motion } from 'framer-motion';

export default function LoadingScreen() {
  return (
    <motion.div
      className="loading-screen"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="loading-spinner" />
      <p className="loading-text">Running Clustering Analysis…</p>
      <p className="loading-subtext">
        Preprocessing → K-Means → PCA → Evaluation
      </p>
    </motion.div>
  );
}
