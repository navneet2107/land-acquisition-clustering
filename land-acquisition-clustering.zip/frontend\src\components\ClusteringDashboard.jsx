import React, { useState } from 'react';
import { motion } from 'framer-motion';

const COLORS = ['#22d3ee', '#a855f7', '#f59e0b', '#ef4444', '#10b981', '#f472b6', '#6366f1'];
const CLUSTER_NAMES = ['Swift Acquisition', 'Procedural Delays', 'Disputed & Complex', 'Severely Stalled', 'Moderate Friction', 'Rural Transition', 'High-Value Urban'];

export default function ClusteringDashboard({ data }) {
  const [selectedK, setSelectedK] = useState(data?.best_k || 4);

  if (!data?.kmeans) return null;

  const kValues = Object.keys(data.kmeans).map(Number).sort((a, b) => a - b);
  const result = data.kmeans[String(selectedK)];

  return (
    <section className="section" id="clustering">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">Step 2</span>
        <h2>K-Means Clustering</h2>
        <p className="subtitle">
          K-Means applied with k ∈ {'{'}{kValues.join(', ')}{'}'} using k-means++
          initialization, 10 restarts, and Euclidean distance. Toggle k to explore
          different configurations.
        </p>
      </motion.div>

      {/* K selector */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 32 }}>
        {kValues.map((k) => (
          <button
            key={k}
            className={`tab ${selectedK === k ? 'active' : ''}`}
            onClick={() => setSelectedK(k)}
            style={{ minWidth: 60 }}
          >
            k = {k}
            {k === data.best_k && ' ★'}
          </button>
        ))}
      </div>

      {/* Cluster cards */}
      {result && (
        <motion.div
          className={`grid-${Math.min(selectedK, 4)}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          key={selectedK}
        >
          {Object.entries(result.cluster_sizes || {}).map(([c, size]) => {
            const idx = parseInt(c);
            const name = CLUSTER_NAMES[idx] || `Cluster ${c}`;
            const silVal = result.cluster_silhouettes?.[c] || 0;
            const total = Object.values(result.cluster_sizes).reduce((a, b) => a + b, 0);
            const pct = ((size / total) * 100).toFixed(1);

            return (
              <motion.div
                className="glass-card"
                key={c}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                style={{ borderLeft: `3px solid ${COLORS[idx % COLORS.length]}` }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
                  <div
                    style={{
                      width: 12, height: 12, borderRadius: '50%',
                      background: COLORS[idx % COLORS.length],
                      boxShadow: `0 0 10px ${COLORS[idx % COLORS.length]}60`,
                    }}
                  />
                  <h3 style={{ fontSize: '1.1rem', color: 'var(--text-primary)' }}>{name}</h3>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 700, color: COLORS[idx % COLORS.length] }}>
                      {size}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      Records ({pct}%)
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                      {silVal.toFixed(3)}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      Silhouette
                    </div>
                  </div>
                </div>

                {/* Progress bar */}
                <div style={{ marginTop: 16 }}>
                  <div className="bar-track">
                    <div
                      className="bar-fill"
                      style={{
                        width: `${pct}%`,
                        background: COLORS[idx % COLORS.length],
                      }}
                    />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {/* Summary metrics for selected k */}
      {result && (
        <motion.div
          className="glass-card"
          style={{ marginTop: 32, textAlign: 'center' }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div style={{ display: 'flex', justifyContent: 'center', gap: 48, flexWrap: 'wrap' }}>
            <div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>WCSS</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--purple-300)' }}>
                {result.wcss?.toFixed(0)}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Silhouette</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--purple-300)' }}>
                {result.silhouette_score?.toFixed(4)}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Davies-Bouldin</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--purple-300)' }}>
                {result.davies_bouldin_score?.toFixed(4)}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Calinski-Harabasz</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--purple-300)' }}>
                {result.calinski_harabasz_score?.toFixed(0)}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </section>
  );
}
