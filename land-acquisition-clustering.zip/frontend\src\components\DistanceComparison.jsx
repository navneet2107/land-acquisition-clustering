import React from 'react';
import { motion } from 'framer-motion';

export default function DistanceComparison({ data }) {
  if (!data) return null;

  const euc = data.euclidean || {};
  const man = data.manhattan || {};

  const rows = [
    { metric: 'Silhouette Score', euclidean: euc.silhouette, manhattan: man.silhouette, better: (euc.silhouette || 0) >= (man.silhouette || 0) ? 'euclidean' : 'manhattan' },
    { metric: 'Inertia / Sum of Distances', euclidean: euc.inertia, manhattan: man.inertia, better: null },
    { metric: 'Davies-Bouldin', euclidean: euc.davies_bouldin, manhattan: '—', better: null },
  ];

  return (
    <section className="section" id="distance">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">Step 5</span>
        <h2>Distance Metric Comparison</h2>
        <p className="subtitle">
          Euclidean (L2) vs Manhattan (L1) distance comparison at k = 4.
          Euclidean uses standard K-Means; Manhattan uses K-Medians (component-wise median centers).
        </p>
      </motion.div>

      <div className="grid-2">
        {/* Euclidean card */}
        <motion.div
          className="glass-card"
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          style={{ borderTop: '3px solid #22d3ee' }}
        >
          <h3 style={{ color: '#22d3ee', marginBottom: 20 }}>
            📐 Euclidean (L2)
          </h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: 20, lineHeight: 1.6 }}>
            Standard K-Means with squared Euclidean distance.
            Sensitive to outliers due to squaring of differences.
            Uses mean as cluster center.
          </p>
          <div className="metric-card" style={{ padding: '16px 0' }}>
            <div className="metric-value" style={{ fontSize: '1.8rem' }}>
              {euc.silhouette?.toFixed(4) || '—'}
            </div>
            <div className="metric-label">Silhouette Score</div>
          </div>
          <div style={{ display: 'flex', gap: 24, justifyContent: 'center', marginTop: 12 }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ color: 'var(--text-primary)', fontWeight: 600 }}>
                {euc.inertia?.toFixed(0) || '—'}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Inertia (WCSS)</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ color: 'var(--text-primary)', fontWeight: 600 }}>
                {euc.davies_bouldin?.toFixed(4) || '—'}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Davies-Bouldin</div>
            </div>
          </div>
        </motion.div>

        {/* Manhattan card */}
        <motion.div
          className="glass-card"
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          style={{ borderTop: '3px solid #f59e0b' }}
        >
          <h3 style={{ color: '#f59e0b', marginBottom: 20 }}>
            🏙 Manhattan (L1)
          </h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: 20, lineHeight: 1.6 }}>
            K-Medians with Manhattan (cityblock) distance.
            More robust to outliers since differences are not squared.
            Uses component-wise median as cluster center.
          </p>
          <div className="metric-card" style={{ padding: '16px 0' }}>
            <div className="metric-value" style={{ fontSize: '1.8rem' }}>
              {man.silhouette?.toFixed(4) || '—'}
            </div>
            <div className="metric-label">Silhouette Score (Manhattan)</div>
          </div>
          <div style={{ display: 'flex', gap: 24, justifyContent: 'center', marginTop: 12 }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ color: 'var(--text-primary)', fontWeight: 600 }}>
                {man.inertia?.toFixed(0) || '—'}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Sum of L1 Distances</div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Comparison table */}
      <motion.div
        className="glass-card"
        style={{ marginTop: 32 }}
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <table className="comparison-table">
          <thead>
            <tr>
              <th>Metric</th>
              <th>Euclidean (K-Means)</th>
              <th>Manhattan (K-Medians)</th>
              <th>Preference</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.metric}>
                <td style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{row.metric}</td>
                <td className={row.better === 'euclidean' ? 'highlight-cell' : ''}>
                  {typeof row.euclidean === 'number' ? row.euclidean.toFixed(4) : (row.euclidean || '—')}
                </td>
                <td className={row.better === 'manhattan' ? 'highlight-cell' : ''}>
                  {typeof row.manhattan === 'number' ? row.manhattan.toFixed(4) : (row.manhattan || '—')}
                </td>
                <td>
                  {row.better === 'euclidean' && <span style={{ color: '#22d3ee' }}>✓ Euclidean</span>}
                  {row.better === 'manhattan' && <span style={{ color: '#f59e0b' }}>✓ Manhattan</span>}
                  {!row.better && <span style={{ color: 'var(--text-muted)' }}>—</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </section>
  );
}
