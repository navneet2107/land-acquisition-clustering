import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  ResponsiveContainer, Tooltip,
} from 'recharts';

const COLORS = ['#22d3ee', '#a855f7', '#f59e0b', '#ef4444', '#10b981', '#f472b6', '#6366f1'];
const CLUSTER_NAMES = ['Swift Acquisition', 'Procedural Delays', 'Disputed & Complex', 'Severely Stalled', 'Moderate Friction'];

const KEY_FEATURES = [
  'delay_days', 'dispute_flag', 'num_owners', 'consent_obtained_pct',
  'digitization_level', 'objections_filed', 'mutation_pending',
  'compensation_offered_lakh', 'rehabilitation_score',
];

export default function ClusterProfiles({ profiles, bestK }) {
  const [selectedCluster, setSelectedCluster] = useState(null);

  if (!profiles) return null;

  const clusterKeys = Object.keys(profiles.profiles || {}).sort();
  const interpretations = profiles.interpretations || {};
  const radarData = profiles.radar_data || [];

  return (
    <section className="section" id="profiles">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">Step 7</span>
        <h2>Cluster Profiles</h2>
        <p className="subtitle">
          Interpretable feature profiles for {clusterKeys.length} discovered clusters.
          Each cluster is characterized by its mean feature values relative to the
          overall dataset distribution.
        </p>
      </motion.div>

      {/* Cluster selector chips */}
      <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginBottom: 32, flexWrap: 'wrap' }}>
        <button
          className={`tab ${selectedCluster === null ? 'active' : ''}`}
          onClick={() => setSelectedCluster(null)}
        >
          All Clusters
        </button>
        {clusterKeys.map((c) => {
          const idx = parseInt(c);
          const name = interpretations[c]?.name || CLUSTER_NAMES[idx] || `Cluster ${c}`;
          return (
            <button
              key={c}
              className={`tab ${selectedCluster === c ? 'active' : ''}`}
              onClick={() => setSelectedCluster(c)}
              style={selectedCluster === c ? {} : {
                borderLeft: `3px solid ${COLORS[idx % COLORS.length]}`,
              }}
            >
              {name}
            </button>
          );
        })}
      </div>

      <div className="grid-2">
        {/* Radar chart */}
        <motion.div
          className="glass-card"
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h3 style={{ color: 'var(--purple-300)', marginBottom: 16, fontSize: '1rem' }}>
            Radar Comparison
          </h3>
          <div style={{ height: 400 }}>
            <ResponsiveContainer>
              <RadarChart data={radarData}>
                <PolarGrid stroke="rgba(120,80,220,0.15)" />
                <PolarAngleAxis
                  dataKey="feature"
                  tick={{ fill: '#7a6b96', fontSize: 10 }}
                />
                <PolarRadiusAxis
                  tick={{ fill: '#7a6b96', fontSize: 9 }}
                  domain={[0, 1]}
                />
                {clusterKeys
                  .filter(c => selectedCluster === null || selectedCluster === c)
                  .map((c) => {
                    const idx = parseInt(c);
                    return (
                      <Radar
                        key={c}
                        name={interpretations[c]?.name || `Cluster ${c}`}
                        dataKey={`cluster_${c}`}
                        stroke={COLORS[idx % COLORS.length]}
                        fill={COLORS[idx % COLORS.length]}
                        fillOpacity={0.15}
                        strokeWidth={2}
                      />
                    );
                  })}
                <Tooltip
                  contentStyle={{
                    background: 'rgba(15,15,46,0.95)',
                    border: '1px solid rgba(120,80,220,0.3)',
                    borderRadius: 10,
                    color: '#b8a9d4',
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Interpretations */}
        <motion.div
          className="glass-card"
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h3 style={{ color: 'var(--purple-300)', marginBottom: 16, fontSize: '1rem' }}>
            Cluster Interpretations
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {clusterKeys
              .filter(c => selectedCluster === null || selectedCluster === c)
              .map((c) => {
                const idx = parseInt(c);
                const interp = interpretations[c] || {};
                const profile = profiles.profiles[c] || {};
                const color = COLORS[idx % COLORS.length];

                return (
                  <motion.div
                    key={c}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    style={{
                      padding: 16,
                      background: `${color}08`,
                      border: `1px solid ${color}25`,
                      borderRadius: 14,
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                      <div style={{
                        width: 10, height: 10, borderRadius: '50%', background: color,
                        boxShadow: `0 0 8px ${color}60`,
                      }} />
                      <h4 style={{ color, fontSize: '1rem' }}>
                        {interp.name || `Cluster ${c}`}
                      </h4>
                      <span style={{
                        marginLeft: 'auto', fontSize: '0.75rem',
                        color: 'var(--text-muted)',
                      }}>
                        {profile.size} records ({profile.percentage}%)
                      </span>
                    </div>
                    <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', lineHeight: 1.5 }}>
                      {interp.description}
                    </p>
                    {interp.key_traits && (
                      <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                        {interp.key_traits.map((trait, i) => (
                          <span
                            key={i}
                            style={{
                              padding: '3px 10px',
                              background: `${color}15`,
                              border: `1px solid ${color}30`,
                              borderRadius: 8,
                              fontSize: '0.7rem',
                              color: color,
                            }}
                          >
                            {trait}
                          </span>
                        ))}
                      </div>
                    )}
                  </motion.div>
                );
              })}
          </div>
        </motion.div>
      </div>

      {/* Detailed feature profiles */}
      <AnimatePresence mode="wait">
        {(selectedCluster !== null) && profiles.profiles[selectedCluster] && (
          <motion.div
            className="glass-card"
            style={{ marginTop: 32 }}
            key={selectedCluster}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <h3 style={{ color: 'var(--purple-300)', marginBottom: 20, fontSize: '1rem' }}>
              Feature Details — {interpretations[selectedCluster]?.name || `Cluster ${selectedCluster}`}
            </h3>
            {KEY_FEATURES.map((feat) => {
              const vals = profiles.profiles[selectedCluster]?.features?.[feat];
              const overall = profiles.overall?.[feat];
              if (!vals || !overall) return null;

              const relativeVal = overall.std > 0
                ? Math.max(0, Math.min(100, ((vals.mean - overall.mean) / (overall.std * 3) + 0.5) * 100))
                : 50;

              return (
                <div className="profile-bar" key={feat}>
                  <div className="bar-label">{feat}</div>
                  <div className="bar-track">
                    <div
                      className="bar-fill"
                      style={{
                        width: `${relativeVal}%`,
                        background: COLORS[parseInt(selectedCluster) % COLORS.length],
                      }}
                    />
                  </div>
                  <div className="bar-value">
                    {vals.mean?.toFixed(2)}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
