import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, Legend,
} from 'recharts';

const COLORS = ['#22d3ee', '#a855f7', '#f59e0b', '#ef4444', '#10b981', '#f472b6', '#6366f1'];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: 'rgba(15,15,46,0.95)', border: '1px solid rgba(120,80,220,0.3)',
      borderRadius: 10, padding: '12px 16px', backdropFilter: 'blur(10px)',
    }}>
      <p style={{ color: '#c084fc', fontWeight: 600, marginBottom: 6 }}>k = {label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color, fontSize: '0.85rem', margin: '2px 0' }}>
          {p.name}: {typeof p.value === 'number' ? p.value.toFixed(4) : p.value}
        </p>
      ))}
    </div>
  );
};

export default function MetricsPanel({ elbow, kmeans, bestK }) {
  const [metric, setMetric] = useState('all');

  if (!elbow) return null;

  // Cluster silhouettes for best k
  const bestResult = kmeans?.[String(bestK)];
  const clusterSilData = bestResult?.cluster_silhouettes
    ? Object.entries(bestResult.cluster_silhouettes).map(([c, val]) => ({
        cluster: `Cluster ${c}`,
        silhouette: parseFloat(val.toFixed(4)),
        fill: COLORS[parseInt(c) % COLORS.length],
      }))
    : [];

  const clusterSizeData = bestResult?.cluster_sizes
    ? Object.entries(bestResult.cluster_sizes).map(([c, size]) => ({
        cluster: `Cluster ${c}`,
        size,
        fill: COLORS[parseInt(c) % COLORS.length],
      }))
    : [];

  return (
    <section className="section" id="metrics">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">Step 4</span>
        <h2>Evaluation Metrics</h2>
        <p className="subtitle">
          WCSS (Elbow Method), Silhouette Score, and Davies-Bouldin Index
          evaluated across k ∈ {'{'}{elbow.map(e => e.k).join(', ')}{'}'}.
          Best k = {bestK} selected by highest Silhouette Score.
        </p>
      </motion.div>

      {/* Best-k summary */}
      <motion.div
        className="grid-4"
        style={{ marginBottom: 32 }}
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        {[
          { label: 'Best k', value: bestK },
          { label: 'WCSS', value: bestResult?.wcss?.toFixed(0) },
          { label: 'Silhouette', value: bestResult?.silhouette_score?.toFixed(4) },
          { label: 'Davies-Bouldin', value: bestResult?.davies_bouldin_score?.toFixed(4) },
        ].map(({ label, value }) => (
          <div className="glass-card metric-card" key={label}>
            <div className="metric-value">{value}</div>
            <div className="metric-label">{label}</div>
          </div>
        ))}
      </motion.div>

      {/* Tabs */}
      <div className="tabs" style={{ margin: '0 auto 24px' }}>
        {[
          ['all', 'All Metrics'],
          ['elbow', 'Elbow (WCSS)'],
          ['silhouette', 'Silhouette'],
          ['davies', 'Davies-Bouldin'],
        ].map(([key, label]) => (
          <button key={key} className={`tab ${metric === key ? 'active' : ''}`} onClick={() => setMetric(key)}>
            {label}
          </button>
        ))}
      </div>

      <div className="grid-2">
        {/* Line charts */}
        <motion.div
          className="glass-card"
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h3 style={{ color: 'var(--purple-300)', marginBottom: 16, fontSize: '1rem' }}>
            {metric === 'elbow' ? 'WCSS (Elbow Method)' :
             metric === 'silhouette' ? 'Silhouette Score' :
             metric === 'davies' ? 'Davies-Bouldin Index' : 'Metrics vs. k'}
          </h3>
          <div style={{ height: 350 }}>
            <ResponsiveContainer>
              <LineChart data={elbow}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(120,80,220,0.1)" />
                <XAxis dataKey="k" stroke="#7a6b96" tick={{ fontSize: 12 }} label={{ value: 'Number of Clusters (k)', position: 'bottom', fill: '#7a6b96', fontSize: 12 }} />
                <YAxis stroke="#7a6b96" tick={{ fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} />
                {(metric === 'all' || metric === 'elbow') && (
                  <Line type="monotone" dataKey="wcss" name="WCSS" stroke="#22d3ee" strokeWidth={2} dot={{ r: 5, fill: '#22d3ee' }} />
                )}
                {(metric === 'all' || metric === 'silhouette') && (
                  <Line type="monotone" dataKey="silhouette" name="Silhouette" stroke="#a855f7" strokeWidth={2} dot={{ r: 5, fill: '#a855f7' }} yAxisId={metric === 'all' ? undefined : undefined} />
                )}
                {(metric === 'all' || metric === 'davies') && (
                  <Line type="monotone" dataKey="davies_bouldin" name="Davies-Bouldin" stroke="#f59e0b" strokeWidth={2} dot={{ r: 5, fill: '#f59e0b' }} />
                )}
                <Legend wrapperStyle={{ color: '#b8a9d4', fontSize: 12 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Cluster breakdown */}
        <motion.div
          className="glass-card"
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h3 style={{ color: 'var(--purple-300)', marginBottom: 16, fontSize: '1rem' }}>
            Cluster Details (k = {bestK})
          </h3>

          {/* Per-cluster silhouette */}
          <h4 style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', margin: '16px 0 8px' }}>
            Per-Cluster Silhouette Score
          </h4>
          <div style={{ height: 160 }}>
            <ResponsiveContainer>
              <BarChart data={clusterSilData} barSize={40}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(120,80,220,0.1)" />
                <XAxis dataKey="cluster" stroke="#7a6b96" tick={{ fontSize: 11 }} />
                <YAxis stroke="#7a6b96" tick={{ fontSize: 11 }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="silhouette" name="Silhouette">
                  {clusterSilData.map((d, i) => (
                    <Cell key={i} fill={d.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Cluster sizes */}
          <h4 style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', margin: '20px 0 8px' }}>
            Cluster Sizes
          </h4>
          <div style={{ height: 160 }}>
            <ResponsiveContainer>
              <BarChart data={clusterSizeData} barSize={40}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(120,80,220,0.1)" />
                <XAxis dataKey="cluster" stroke="#7a6b96" tick={{ fontSize: 11 }} />
                <YAxis stroke="#7a6b96" tick={{ fontSize: 11 }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="size" name="Size">
                  {clusterSizeData.map((d, i) => (
                    <Cell key={i} fill={d.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* Metrics comparison table */}
      <motion.div
        className="glass-card"
        style={{ marginTop: 32 }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <h3 style={{ color: 'var(--purple-300)', marginBottom: 16, fontSize: '1rem' }}>
          Full Metrics Comparison
        </h3>
        <table className="comparison-table">
          <thead>
            <tr>
              <th>k</th>
              <th>WCSS</th>
              <th>Silhouette</th>
              <th>Davies-Bouldin</th>
              <th>Calinski-Harabasz</th>
              <th>Best?</th>
            </tr>
          </thead>
          <tbody>
            {elbow.map((row) => (
              <tr key={row.k} style={row.k === bestK ? { background: 'rgba(120,80,220,0.1)' } : {}}>
                <td style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{row.k}</td>
                <td>{row.wcss?.toFixed(0)}</td>
                <td className={row.k === bestK ? 'highlight-cell' : ''}>{row.silhouette?.toFixed(4)}</td>
                <td>{row.davies_bouldin?.toFixed(4)}</td>
                <td>{row.calinski_harabasz?.toFixed(0)}</td>
                <td>{row.k === bestK ? '✅' : ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </section>
  );
}
