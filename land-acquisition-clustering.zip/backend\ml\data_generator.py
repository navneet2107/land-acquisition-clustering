"""
Data Generator for Land Acquisition Delay Pattern Segmentation.
Generates synthetic dataset simulating DILRMP (Digital India Land Records
Modernization Programme) open land-record dashboard data.
"""

import numpy as np
import pandas as pd
from typing import Optional


def generate_land_acquisition_dataset(
    n_samples: int = 2000,
    random_state: int = 42
) -> pd.DataFrame:
    """
    Generate a synthetic dataset mimicking DILRMP land acquisition records.
    
    Features generated:
    - state_code: Encoded Indian state (categorical → numeric)
    - district_code: Encoded district (categorical → numeric)
    - land_type: Type of land (Agricultural, Residential, Commercial, Industrial, Forest)
    - area_hectares: Area of land in hectares
    - num_owners: Number of land owners involved
    - dispute_flag: Whether there's a legal dispute (0/1)
    - encumbrance_flag: Whether the land has encumbrances (0/1)
    - mutation_pending: Number of pending mutation entries
    - days_since_notification: Days since Section 11 notification
    - days_to_award: Days taken for award under Section 23
    - compensation_offered_lakh: Compensation offered in lakhs
    - market_value_ratio: Ratio of offered compensation to market value
    - num_hearings: Number of hearings conducted
    - objections_filed: Number of objections filed by owners
    - rehabilitation_score: R&R compliance score (0-100)
    - digitization_level: Level of record digitization (0-100%)
    - survey_completion_pct: Percentage of survey completed
    - consent_obtained_pct: Percentage of consent obtained
    - delay_category: Target-like label for reference (not used in clustering)
    - delay_days: Total delay in days from expected timeline
    """
    
    rng = np.random.RandomState(random_state)
    
    # Indian states (encoded)
    states = list(range(1, 29))  # 28 states
    state_codes = rng.choice(states, n_samples)
    
    # District codes (1-50 per state, simplified)
    district_codes = rng.randint(1, 51, n_samples)
    
    # Land types
    land_type_map = {0: 'Agricultural', 1: 'Residential', 2: 'Commercial', 
                     3: 'Industrial', 4: 'Forest'}
    # Weighted probabilities
    land_type_probs = [0.40, 0.25, 0.15, 0.10, 0.10]
    land_types = rng.choice(list(land_type_map.keys()), n_samples, p=land_type_probs)
    
    # Area in hectares (log-normal distribution)
    area_hectares = np.round(rng.lognormal(mean=2.0, sigma=1.2, size=n_samples), 2)
    area_hectares = np.clip(area_hectares, 0.1, 500.0)
    
    # Number of owners
    num_owners = rng.poisson(lam=3, size=n_samples) + 1
    num_owners = np.clip(num_owners, 1, 50)
    
    # Dispute flag (correlated with land type and owners)
    dispute_base = 0.15 + 0.05 * (land_types >= 2) + 0.02 * np.minimum(num_owners, 10)
    dispute_flag = (rng.random(n_samples) < dispute_base).astype(int)
    
    # Encumbrance flag
    encumbrance_base = 0.20 + 0.10 * dispute_flag
    encumbrance_flag = (rng.random(n_samples) < encumbrance_base).astype(int)
    
    # Mutation pending entries
    mutation_pending = rng.poisson(lam=1.5 + dispute_flag * 2, size=n_samples)
    
    # Days since notification (Section 11)
    days_since_notification = rng.randint(30, 1800, n_samples)
    
    # Compensation (correlated with land type and area)
    base_rate = np.array([2.0, 8.0, 15.0, 12.0, 1.5])[land_types]
    compensation_offered_lakh = np.round(
        area_hectares * base_rate * rng.uniform(0.7, 1.5, n_samples), 2
    )
    
    # Market value ratio
    market_value_ratio = np.round(rng.uniform(0.5, 1.8, n_samples), 3)
    
    # Number of hearings
    num_hearings = rng.poisson(
        lam=3 + dispute_flag * 4 + encumbrance_flag * 2, size=n_samples
    )
    
    # Objections filed
    objections_filed = rng.poisson(
        lam=1 + dispute_flag * 3 + (market_value_ratio < 0.8) * 2, size=n_samples
    )
    
    # Rehabilitation score (0-100)
    rehabilitation_score = np.round(
        rng.beta(a=5, b=3, size=n_samples) * 100, 1
    )
    
    # Digitization level
    digitization_level = np.round(
        rng.beta(a=3, b=2, size=n_samples) * 100, 1
    )
    
    # Survey completion percentage
    survey_completion_pct = np.round(
        rng.beta(a=4, b=2, size=n_samples) * 100, 1
    )
    
    # Consent obtained percentage
    consent_obtained_pct = np.round(
        np.clip(
            rng.normal(loc=65, scale=20, size=n_samples),
            0, 100
        ), 1
    )
    
    # === Delay computation (synthetic target) ===
    # Base delay influenced by multiple factors
    delay_days = (
        50 * dispute_flag +
        30 * encumbrance_flag +
        5 * mutation_pending +
        2 * num_owners +
        0.5 * (100 - consent_obtained_pct) +
        0.3 * (100 - digitization_level) +
        3 * objections_filed +
        rng.normal(0, 15, n_samples)
    ).astype(int)
    delay_days = np.clip(delay_days, 0, 500)
    
    # Days to award
    days_to_award = np.clip(
        (180 + delay_days * 0.8 + rng.normal(0, 30, n_samples)).astype(int),
        90, 1200
    )
    
    # Delay category (reference label)
    delay_category = pd.cut(
        delay_days,
        bins=[-1, 30, 90, 180, 500],
        labels=['Minimal', 'Moderate', 'Significant', 'Severe']
    )
    
    # Build DataFrame
    df = pd.DataFrame({
        'state_code': state_codes,
        'district_code': district_codes,
        'land_type': land_types,
        'area_hectares': area_hectares,
        'num_owners': num_owners,
        'dispute_flag': dispute_flag,
        'encumbrance_flag': encumbrance_flag,
        'mutation_pending': mutation_pending,
        'days_since_notification': days_since_notification,
        'days_to_award': days_to_award,
        'compensation_offered_lakh': compensation_offered_lakh,
        'market_value_ratio': market_value_ratio,
        'num_hearings': num_hearings,
        'objections_filed': objections_filed,
        'rehabilitation_score': rehabilitation_score,
        'digitization_level': digitization_level,
        'survey_completion_pct': survey_completion_pct,
        'consent_obtained_pct': consent_obtained_pct,
        'delay_days': delay_days,
        'delay_category': delay_category,
    })
    
    # Inject ~5% missing values in select columns
    missing_cols = [
        'area_hectares', 'compensation_offered_lakh', 'market_value_ratio',
        'rehabilitation_score', 'digitization_level', 'consent_obtained_pct'
    ]
    for col in missing_cols:
        mask = rng.random(n_samples) < 0.05
        df.loc[mask, col] = np.nan
    
    return df


def get_feature_descriptions() -> dict:
    """Return human-readable descriptions for each feature."""
    return {
        'state_code': 'Encoded Indian state identifier',
        'district_code': 'Encoded district identifier within state',
        'land_type': 'Type of land (0=Agricultural, 1=Residential, 2=Commercial, 3=Industrial, 4=Forest)',
        'area_hectares': 'Area of land parcel in hectares',
        'num_owners': 'Number of registered land owners',
        'dispute_flag': 'Whether land has an active legal dispute (0/1)',
        'encumbrance_flag': 'Whether land has encumbrances (0/1)',
        'mutation_pending': 'Number of pending mutation entries',
        'days_since_notification': 'Days since Section 11 notification issued',
        'days_to_award': 'Days taken for compensation award (Section 23)',
        'compensation_offered_lakh': 'Compensation offered in lakhs (INR)',
        'market_value_ratio': 'Ratio of offered compensation to estimated market value',
        'num_hearings': 'Number of hearings conducted',
        'objections_filed': 'Number of objections filed by land owners',
        'rehabilitation_score': 'R&R (Rehabilitation & Resettlement) compliance score (0-100)',
        'digitization_level': 'Level of land record digitization (0-100%)',
        'survey_completion_pct': 'Percentage of cadastral survey completed',
        'consent_obtained_pct': 'Percentage of owner consent obtained',
        'delay_days': 'Total delay in days from expected acquisition timeline',
        'delay_category': 'Delay severity (Minimal/Moderate/Significant/Severe)',
    }
