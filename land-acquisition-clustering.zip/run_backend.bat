@echo off
echo ========================================================
echo Starting LACPS FastAPI Machine Learning Backend Server...
echo ========================================================
cd /d %~dp0backend
echo Installing requirements...
pip install -r requirements.txt
echo Running Uvicorn FastAPI Server on http://localhost:8000
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
pause
