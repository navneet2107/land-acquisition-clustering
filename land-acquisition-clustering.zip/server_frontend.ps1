# Lightweight High-Performance Frontend Server for LACPS
param([int]$Port = 3000)

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$Port/")
try {
    $listener.Start()
    Write-Host "LACPS Frontend Web Application running at http://localhost:$Port/"
} catch {
    Write-Error "Failed to bind to port ${Port} : $_"
    exit 1
}

$htmlPath = "C:\Users\navne\.gemini\antigravity\scratch\land-acquisition-clustering\index.html"

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $response.Headers.Add("Access-Control-Allow-Origin", "*")
        $response.ContentType = "text/html; charset=utf-8"

        if (Test-Path $htmlPath) {
            $buffer = [System.IO.File]::ReadAllBytes($htmlPath)
            $response.ContentLength64 = $buffer.Length
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        } else {
            $notFound = [System.Text.Encoding]::UTF8.GetBytes("<h1>404 - index.html not found</h1>")
            $response.StatusCode = 404
            $response.OutputStream.Write($notFound, 0, $notFound.Length)
        }
        $response.OutputStream.Close()
    } catch {
        # Continue loop on client disconnect
    }
}
