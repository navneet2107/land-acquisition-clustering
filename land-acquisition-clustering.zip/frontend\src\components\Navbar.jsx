import React from 'react';
import { motion } from 'framer-motion';

export default function Navbar({ onRunAnalysis, loading }) {
  return (
    <motion.nav
      className="navbar"
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: 'easeOut' }}
    >
      <div className="navbar-logo">
        <div className="logo-icon">🔬</div>
        <span>LACPS</span>
      </div>

      <ul className="navbar-links">
        <li><a href="#overview">Overview</a></li>
        <li><a href="#clustering">Clustering</a></li>
        <li><a href="#pca">PCA</a></li>
        <li><a href="#metrics">Metrics</a></li>
        <li><a href="#profiles">Profiles</a></li>
        <li><a href="#limitations">Ethics</a></li>
      </ul>

      <button
        className="btn-primary"
        onClick={onRunAnalysis}
        disabled={loading}
        style={{ padding: '10px 24px', fontSize: '0.85rem' }}
      >
        {loading ? '⏳ Analyzing…' : '🚀 Run Analysis'}
      </button>
    </motion.nav>
  );
}
