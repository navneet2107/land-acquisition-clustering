import React, { useState, useEffect, useCallback } from 'react';
import { AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import DataOverview from './components/DataOverview';
import ClusteringDashboard from './components/ClusteringDashboard';
import PCAVisualization from './components/PCAVisualization';
import MetricsPanel from './components/MetricsPanel';
import ClusterProfiles from './components/ClusterProfiles';
import DistanceComparison from './components/DistanceComparison';
import HierarchicalView from './components/HierarchicalView';
import Limitations from './components/Limitations';
import Footer from './components/Footer';
import LoadingScreen from './components/LoadingScreen';

export default function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeSection, setActiveSection] = useState('hero');

  const runAnalysis = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ n_samples: 2000 }),
      });
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const result = await res.json();
      setData(result);
    } catch (err) {
      setError(err.message);
      // Load mock data for demo
      setData(generateMockData());
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    runAnalysis();
  }, [runAnalysis]);

  return (
    <div className="app">
      <Navbar activeSection={activeSection} onRunAnalysis={runAnalysis} loading={loading} />
      <AnimatePresence mode="wait">
        {loading && !data && <LoadingScreen key="loading" />}
      </AnimatePresence>
      <main>
        <Hero onAnalyze={runAnalysis} loading={loading} hasData={!!data} />
        {data && (
          <>
            <DataOverview data={data.dataset_summary} />
            <ClusteringDashboard data={data} />
            <PCAVisualization pca={data.pca} scatter={data.pca_scatter} bestK={data.best_k} />
            <MetricsPanel elbow={data.elbow_data} kmeans={data.kmeans} bestK={data.best_k} />
            <DistanceComparison data={data.distance_comparison} />
            <HierarchicalView data={data.hierarchical} />
            <ClusterProfiles profiles={data.profiles} bestK={data.best_k} />
            <Limitations
              limitations={data.limitations}
              ethical={data.ethical_considerations}
            />
          </>
        )}
        {error && !data && (
          <div className="error-banner">
            <p>⚠ Could not connect to backend: {error}</p>
            <button onClick={runAnalysis}>Retry</button>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

/* ── Mock data generator for standalone frontend demo ── */
function generateMockData() {
  const rand = (min, max) => Math.random() * (max - min) + min;
  const randInt = (min, max) => Math.floor(rand(min, max));

  const n = 600;
  const pca_scatter = Array.from({ length: n }, (_, i) => {
    const cluster = i % 4;
    const cx = [-2, 2, -1, 3][cluster];
    const cy = [1, -1, -2, 2][cluster];
    return {
      x: parseFloat((cx + rand(-1.5, 1.5)).toFixed(4)),
      y: parseFloat((cy + rand(-1.5, 1.5)).toFixed(4)),
      z: parseFloat(rand(-2, 2).toFixed(4)),
      cluster,
    };
  });

  const elbow_data = [3, 4, 5, 6, 7].map(k => ({
    k,
    wcss: 50000 / k + rand(500, 2000),
    silhouette: 0.15 + 0.12 / k + rand(-0.02, 0.02),
    davies_bouldin: 1.0 + k * 0.15 + rand(-0.1, 0.1),
    calinski_harabasz: 800 - k * 50 + rand(-30, 30),
  }));

  const makeCluster = (id, size, delay, dispute, consent, digit) => ({
    size,
    percentage: parseFloat((size / 20).toFixed(1)),
    features: {
      delay_days: { mean: delay, median: delay - 5, std: 15, min: delay - 30, max: delay + 40 },
      dispute_flag: { mean: dispute, median: 0, std: 0.3, min: 0, max: 1 },
      consent_obtained_pct: { mean: consent, median: consent + 2, std: 12, min: 20, max: 95 },
      digitization_level: { mean: digit, median: digit - 3, std: 10, min: 20, max: 95 },
      num_owners: { mean: 3 + id, median: 3, std: 2, min: 1, max: 15 },
      objections_filed: { mean: id * 1.5, median: id, std: 2, min: 0, max: 12 },
      area_hectares: { mean: 10 + id * 5, median: 8, std: 15, min: 0.5, max: 100 },
      compensation_offered_lakh: { mean: 50 + id * 20, median: 40, std: 30, min: 5, max: 200 },
      rehabilitation_score: { mean: 70 - id * 10, median: 65, std: 15, min: 10, max: 95 },
      mutation_pending: { mean: id, median: 0, std: 2, min: 0, max: 8 },
      encumbrance_flag: { mean: 0.1 + id * 0.1, median: 0, std: 0.3, min: 0, max: 1 },
      num_hearings: { mean: 3 + id * 2, median: 3, std: 3, min: 0, max: 15 },
      market_value_ratio: { mean: 1.0 - id * 0.1, median: 1.0, std: 0.2, min: 0.5, max: 1.5 },
      land_type: { mean: id % 5, median: id % 5, std: 1, min: 0, max: 4 },
      days_since_notification: { mean: 300 + id * 100, median: 280, std: 150, min: 30, max: 1200 },
      days_to_award: { mean: 250 + id * 60, median: 230, std: 80, min: 90, max: 800 },
      survey_completion_pct: { mean: 80 - id * 10, median: 75, std: 15, min: 20, max: 100 },
    },
  });

  const profiles = {
    profiles: {
      '0': makeCluster(0, 550, 25, 0.08, 82, 78),
      '1': makeCluster(1, 480, 65, 0.22, 60, 55),
      '2': makeCluster(2, 520, 130, 0.45, 42, 40),
      '3': makeCluster(3, 450, 200, 0.62, 28, 32),
    },
    overall: Object.fromEntries(
      ['delay_days','dispute_flag','consent_obtained_pct','digitization_level',
       'num_owners','objections_filed','area_hectares','compensation_offered_lakh',
       'rehabilitation_score','mutation_pending','encumbrance_flag','num_hearings',
       'market_value_ratio','land_type','days_since_notification','days_to_award',
       'survey_completion_pct'].map(f => [f, { mean: 50, std: 20 }])
    ),
    interpretations: {
      '0': { name: 'Swift Acquisition', description: 'Swift Acquisition: low delay, good consent levels, well-digitized', key_traits: ['low delay', 'good consent levels', 'well-digitized'] },
      '1': { name: 'Procedural Delays', description: 'Procedural Delays: moderate delay', key_traits: ['moderate delay'] },
      '2': { name: 'Disputed & Complex', description: 'Disputed & Complex: high delay, high dispute rate, low consent', key_traits: ['high delay', 'high dispute rate', 'low consent'] },
      '3': { name: 'Severely Stalled', description: 'Severely Stalled: high delay, high dispute rate, low consent, multi-owner', key_traits: ['high delay', 'high dispute rate', 'low consent', 'multi-owner'] },
    },
    radar_data: ['delay_days','dispute_flag','num_owners','consent_obtained_pct','digitization_level','objections_filed','area_hectares','compensation_offered_lakh','rehabilitation_score'].map(f => ({
      feature: f, cluster_0: rand(0.1, 0.4), cluster_1: rand(0.3, 0.6), cluster_2: rand(0.5, 0.8), cluster_3: rand(0.7, 0.95),
    })),
  };

  return {
    dataset_summary: {
      n_samples: 2000, n_features: 17,
      features: ['land_type','area_hectares','num_owners','dispute_flag','encumbrance_flag','mutation_pending','days_since_notification','days_to_award','compensation_offered_lakh','market_value_ratio','num_hearings','objections_filed','rehabilitation_score','digitization_level','survey_completion_pct','consent_obtained_pct','delay_days'],
      missing_values: { area_hectares: 98, compensation_offered_lakh: 105, market_value_ratio: 92, rehabilitation_score: 88, digitization_level: 95, consent_obtained_pct: 102 },
      basic_stats: Object.fromEntries(['land_type','area_hectares','num_owners','dispute_flag','encumbrance_flag','mutation_pending','days_since_notification','days_to_award','compensation_offered_lakh','market_value_ratio','num_hearings','objections_filed','rehabilitation_score','digitization_level','survey_completion_pct','consent_obtained_pct','delay_days'].map(f => [f, { mean: rand(10,80), std: rand(5,30), min: rand(0,5), max: rand(80,500), median: rand(10,70) }])),
    },
    pca: {
      explained_variance_ratio: [0.182, 0.143, 0.112],
      cumulative_variance: [0.182, 0.325, 0.437],
      scree_data: { components: Array.from({length:17},(_,i)=>i+1), explained_variance: Array.from({length:17},(_,i)=>0.18*Math.exp(-i*0.2)), cumulative_variance: [] },
      loadings: ['land_type','area_hectares','num_owners','dispute_flag','encumbrance_flag','mutation_pending','days_since_notification','days_to_award','compensation_offered_lakh','market_value_ratio','num_hearings','objections_filed','rehabilitation_score','digitization_level','survey_completion_pct','consent_obtained_pct','delay_days'].map(f => ({ feature: f, pc1: rand(-0.4, 0.4), pc2: rand(-0.4, 0.4) })),
    },
    pca_scatter,
    kmeans: Object.fromEntries([3,4,5,6,7].map(k => [String(k), {
      k, wcss: 50000/k + rand(500,2000), silhouette_score: 0.15 + 0.12/k + rand(-0.02,0.02),
      davies_bouldin_score: 1.0 + k * 0.15, calinski_harabasz_score: 800 - k * 50,
      cluster_sizes: Object.fromEntries(Array.from({length:k},(_,i)=>[String(i), randInt(200,600)])),
      cluster_silhouettes: Object.fromEntries(Array.from({length:k},(_,i)=>[String(i), rand(0.1,0.4)])),
    }])),
    elbow_data,
    distance_comparison: {
      euclidean: { silhouette: 0.287, davies_bouldin: 1.42, inertia: 12500 },
      manhattan: { silhouette: 0.265, inertia: 18200 },
    },
    hierarchical: {
      silhouette_score: 0.271, davies_bouldin_score: 1.38,
      cluster_sizes: { '0': 520, '1': 490, '2': 510, '3': 480 },
      linkage_method: 'ward', n_clusters: 4,
    },
    best_k: 4,
    profiles,
    limitations: [
      { title: 'Synthetic Data', description: 'This analysis uses synthetically generated data modeled after DILRMP patterns.' },
      { title: 'Feature Selection Bias', description: 'The 17 features selected may not capture all factors influencing acquisition delays.' },
      { title: 'Sampling Bias', description: 'The synthetic generation uses uniform state sampling.' },
      { title: 'Cluster Stability', description: 'K-Means results depend on initialization and may vary across runs.' },
      { title: 'Scaling Assumptions', description: 'StandardScaler assumes features are roughly Gaussian.' },
      { title: 'Temporal Dynamics', description: 'The snapshot-based analysis does not capture how delay patterns evolve over time.' },
    ],
    ethical_considerations: [
      { title: 'Potential for Discriminatory Application', description: 'Clustering results should not be used to deny or delay services to specific communities.' },
      { title: 'Privacy and Consent', description: 'Real DILRMP data contains PII. Deployment must comply with data protection regulations.' },
      { title: 'Stakeholder Impact', description: 'Land acquisition directly affects livelihoods.' },
      { title: 'Transparency', description: 'Methodology and limitations should be fully disclosed to stakeholders.' },
      { title: 'Avoiding Automation Bias', description: 'These clusters should inform, not replace, human judgment.' },
      { title: 'Equitable Resource Allocation', description: 'Care must be taken to ensure marginalized communities receive equitable attention.' },
    ],
    meta: { computation_time_seconds: 0, n_samples: 2000 },
  };
}
