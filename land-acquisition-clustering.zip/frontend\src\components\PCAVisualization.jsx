import React, { useState, useMemo, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';

const COLORS = ['#22d3ee', '#a855f7', '#f59e0b', '#ef4444', '#10b981', '#f472b6', '#6366f1'];

export default function PCAVisualization({ pca, scatter, bestK }) {
  const canvasRef = useRef(null);
  const [hoveredPoint, setHoveredPoint] = useState(null);
  const [view, setView] = useState('scatter');

  // ── Draw PCA scatter on canvas ──
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !scatter || view !== 'scatter') return;

    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    const W = rect.width;
    const H = rect.height;

    // Clear
    ctx.fillStyle = 'rgba(10, 10, 26, 0.95)';
    ctx.fillRect(0, 0, W, H);

    // Find bounds
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of scatter) {
      if (p.x < minX) minX = p.x;
      if (p.x > maxX) maxX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.y > maxY) maxY = p.y;
    }
    const pad = 60;
    const rangeX = maxX - minX || 1;
    const rangeY = maxY - minY || 1;
    const scaleX = (W - pad * 2) / rangeX;
    const scaleY = (H - pad * 2) / rangeY;
    const toX = (v) => pad + (v - minX) * scaleX;
    const toY = (v) => H - pad - (v - minY) * scaleY;

    // Grid lines
    ctx.strokeStyle = 'rgba(120, 80, 220, 0.08)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      const x = pad + ((W - pad * 2) / 5) * i;
      const y = pad + ((H - pad * 2) / 5) * i;
      ctx.beginPath(); ctx.moveTo(x, pad); ctx.lineTo(x, H - pad); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(pad, y); ctx.lineTo(W - pad, y); ctx.stroke();
    }

    // Draw points
    for (const p of scatter) {
      const px = toX(p.x);
      const py = toY(p.y);
      const color = COLORS[p.cluster % COLORS.length];

      // Glow
      ctx.beginPath();
      ctx.arc(px, py, 6, 0, Math.PI * 2);
      ctx.fillStyle = color + '20';
      ctx.fill();

      // Point
      ctx.beginPath();
      ctx.arc(px, py, 3, 0, Math.PI * 2);
      ctx.fillStyle = color + 'cc';
      ctx.fill();
    }

    // Axis labels
    ctx.fillStyle = '#7a6b96';
    ctx.font = '12px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Principal Component 1', W / 2, H - 15);
    ctx.save();
    ctx.translate(18, H / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText('Principal Component 2', 0, 0);
    ctx.restore();

    // Legend
    const legendX = W - 160;
    const legendY = 25;
    ctx.fillStyle = 'rgba(15, 15, 46, 0.8)';
    ctx.fillRect(legendX - 10, legendY - 10, 150, bestK * 24 + 20);
    for (let i = 0; i < bestK; i++) {
      ctx.fillStyle = COLORS[i % COLORS.length];
      ctx.beginPath();
      ctx.arc(legendX + 8, legendY + i * 24 + 8, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#b8a9d4';
      ctx.font = '11px Inter, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(`Cluster ${i}`, legendX + 20, legendY + i * 24 + 12);
    }
  }, [scatter, bestK, view]);

  // ── Variance data ──
  const varianceData = pca?.explained_variance_ratio || [];
  const cumulativeData = pca?.cumulative_variance || [];
  const screeData = pca?.scree_data || {};
  const loadings = pca?.loadings || [];

  return (
    <section className="section" id="pca">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">Step 3</span>
        <h2>PCA Visualization</h2>
        <p className="subtitle">
          Principal Component Analysis reduces {loadings.length} features to interpretable
          2D/3D spaces. First 3 components explain{' '}
          {(cumulativeData[2] * 100 || 0).toFixed(1)}% of total variance.
        </p>
      </motion.div>

      {/* Tabs */}
      <div className="tabs" style={{ margin: '0 auto 24px' }}>
        {['scatter', 'variance', 'loadings'].map((v) => (
          <button
            key={v}
            className={`tab ${view === v ? 'active' : ''}`}
            onClick={() => setView(v)}
          >
            {v === 'scatter' ? '2D Scatter' : v === 'variance' ? 'Variance Explained' : 'Feature Loadings'}
          </button>
        ))}
      </div>

      {/* Variance summary cards */}
      <motion.div
        className="grid-3"
        style={{ marginBottom: 32 }}
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        {varianceData.slice(0, 3).map((v, i) => (
          <div className="glass-card metric-card" key={i}>
            <div className="metric-value">{(v * 100).toFixed(1)}%</div>
            <div className="metric-label">PC{i + 1} Variance</div>
          </div>
        ))}
      </motion.div>

      {/* Main visualization */}
      <motion.div
        className="glass-card"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        {view === 'scatter' && (
          <div className="pca-scatter-container">
            <canvas
              ref={canvasRef}
              style={{ width: '100%', height: '100%', borderRadius: 16 }}
            />
          </div>
        )}

        {view === 'variance' && (
          <div style={{ padding: 20 }}>
            <h3 style={{ color: 'var(--purple-300)', marginBottom: 20 }}>Scree Plot — Explained Variance</h3>
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end', height: 300, padding: '0 20px' }}>
              {(screeData.explained_variance || []).map((v, i) => (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', marginBottom: 4 }}>
                    {(v * 100).toFixed(1)}%
                  </span>
                  <div
                    style={{
                      width: '100%',
                      maxWidth: 40,
                      height: `${v * 100 * 3}%`,
                      minHeight: 4,
                      background: i < 3
                        ? 'linear-gradient(180deg, #a855f7, #7c3aed)'
                        : 'rgba(120, 80, 220, 0.3)',
                      borderRadius: '6px 6px 0 0',
                      transition: 'height 0.5s',
                    }}
                  />
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: 6 }}>
                    PC{i + 1}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {view === 'loadings' && (
          <div style={{ padding: 20 }}>
            <h3 style={{ color: 'var(--purple-300)', marginBottom: 20 }}>Feature Loadings on PC1 & PC2</h3>
            {loadings
              .sort((a, b) => Math.abs(b.pc1) - Math.abs(a.pc1))
              .map((l) => (
                <div key={l.feature} className="profile-bar">
                  <div className="bar-label">{l.feature}</div>
                  <div className="bar-track" style={{ position: 'relative' }}>
                    {/* PC1 bar */}
                    <div
                      className="bar-fill"
                      style={{
                        width: `${Math.abs(l.pc1) * 100 * 2.5}%`,
                        maxWidth: '100%',
                        background: l.pc1 > 0 ? '#a855f7' : '#22d3ee',
                        position: 'absolute',
                        left: l.pc1 > 0 ? '50%' : `${50 - Math.abs(l.pc1) * 100 * 2.5}%`,
                      }}
                    />
                  </div>
                  <div className="bar-value" style={{ fontSize: '0.75rem' }}>
                    {l.pc1.toFixed(3)}
                  </div>
                </div>
              ))}
          </div>
        )}
      </motion.div>
    </section>
  );
}
