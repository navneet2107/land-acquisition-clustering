"""
ML Pipeline for Land Acquisition Delay Pattern Segmentation.
Implements preprocessing, K-Means clustering, hierarchical clustering,
PCA visualization, and evaluation metrics.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.metrics import (
    silhouette_score,
    silhouette_samples,
    davies_bouldin_score,
    calinski_harabasz_score,
)
from sklearn.impute import SimpleImputer
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from scipy.spatial.distance import cdist
from typing import Dict, List, Any, Optional, Tuple
import json


# ── Features used for clustering (exclude identifiers and reference labels) ──
CLUSTERING_FEATURES = [
    'land_type', 'area_hectares', 'num_owners', 'dispute_flag',
    'encumbrance_flag', 'mutation_pending', 'days_since_notification',
    'days_to_award', 'compensation_offered_lakh', 'market_value_ratio',
    'num_hearings', 'objections_filed', 'rehabilitation_score',
    'digitization_level', 'survey_completion_pct', 'consent_obtained_pct',
    'delay_days',
]


def preprocess_data(df: pd.DataFrame) -> Tuple[np.ndarray, pd.DataFrame, StandardScaler]:
    """
    Preprocess data for clustering:
    1. Select clustering features
    2. Impute missing values (median strategy)
    3. StandardScaler normalization
    
    Returns: (scaled_data, cleaned_df, scaler)
    """
    features_df = df[CLUSTERING_FEATURES].copy()
    
    # Impute missing values with median
    imputer = SimpleImputer(strategy='median')
    imputed_data = imputer.fit_transform(features_df)
    cleaned_df = pd.DataFrame(imputed_data, columns=CLUSTERING_FEATURES)
    
    # Scale features
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(cleaned_df)
    
    return scaled_data, cleaned_df, scaler


def run_pca(scaled_data: np.ndarray, n_components: int = 3) -> Dict[str, Any]:
    """
    Run PCA for visualization and analysis.
    Returns PCA-transformed data and explained variance.
    """
    pca = PCA(n_components=n_components)
    pca_data = pca.fit_transform(scaled_data)
    
    # Full PCA for scree plot
    pca_full = PCA()
    pca_full.fit(scaled_data)
    
    return {
        'pca_data_2d': pca_data[:, :2].tolist(),
        'pca_data_3d': pca_data[:, :3].tolist() if n_components >= 3 else None,
        'explained_variance_ratio': pca.explained_variance_ratio_.tolist(),
        'cumulative_variance': np.cumsum(pca.explained_variance_ratio_).tolist(),
        'components': pca.components_.tolist(),
        'feature_names': CLUSTERING_FEATURES,
        'scree_data': {
            'components': list(range(1, len(pca_full.explained_variance_ratio_) + 1)),
            'explained_variance': pca_full.explained_variance_ratio_.tolist(),
            'cumulative_variance': np.cumsum(pca_full.explained_variance_ratio_).tolist(),
        },
        'loadings': [
            {
                'feature': feat,
                'pc1': float(pca.components_[0, i]),
                'pc2': float(pca.components_[1, i]),
            }
            for i, feat in enumerate(CLUSTERING_FEATURES)
        ],
    }


def run_kmeans_analysis(
    scaled_data: np.ndarray,
    k_values: List[int] = [3, 4, 5, 6, 7],
) -> Dict[str, Any]:
    """
    Run K-Means with multiple k values and evaluate each.
    Returns metrics and cluster assignments for each k.
    """
    results = {}
    
    for k in k_values:
        kmeans = KMeans(n_clusters=k, init='k-means++', n_init=10,
                        max_iter=300, random_state=42)
        labels = kmeans.fit_predict(scaled_data)
        
        wcss = float(kmeans.inertia_)
        sil_score = float(silhouette_score(scaled_data, labels))
        db_score = float(davies_bouldin_score(scaled_data, labels))
        ch_score = float(calinski_harabasz_score(scaled_data, labels))
        
        # Silhouette samples for detailed analysis
        sil_samples = silhouette_samples(scaled_data, labels)
        
        # Per-cluster silhouette
        cluster_sil = {}
        for c in range(k):
            mask = labels == c
            cluster_sil[str(c)] = float(np.mean(sil_samples[mask]))
        
        # Cluster sizes
        cluster_sizes = {}
        for c in range(k):
            cluster_sizes[str(c)] = int(np.sum(labels == c))
        
        # Cluster centers (in original scale would need inverse_transform)
        centers = kmeans.cluster_centers_.tolist()
        
        results[str(k)] = {
            'k': k,
            'wcss': wcss,
            'silhouette_score': sil_score,
            'davies_bouldin_score': db_score,
            'calinski_harabasz_score': ch_score,
            'cluster_silhouettes': cluster_sil,
            'cluster_sizes': cluster_sizes,
            'labels': labels.tolist(),
            'centers': centers,
        }
    
    return results


def compare_distance_metrics(
    scaled_data: np.ndarray,
    k: int = 4,
) -> Dict[str, Any]:
    """
    Compare Euclidean vs Manhattan distance for K-Means-like clustering.
    Uses custom implementation for Manhattan and sklearn for Euclidean.
    """
    # Euclidean (standard K-Means)
    kmeans_euclidean = KMeans(n_clusters=k, init='k-means++', n_init=10,
                              max_iter=300, random_state=42)
    labels_euc = kmeans_euclidean.fit_predict(scaled_data)
    sil_euc = float(silhouette_score(scaled_data, labels_euc))
    db_euc = float(davies_bouldin_score(scaled_data, labels_euc))
    wcss_euc = float(kmeans_euclidean.inertia_)
    
    # Manhattan approximation using iterative median-based clustering
    # (K-Medians via iterative assignment)
    labels_man = _kmedians(scaled_data, k, random_state=42)
    sil_man = float(silhouette_score(scaled_data, labels_man, metric='manhattan'))
    
    # Compute Manhattan-based "WCSS" equivalent (sum of L1 distances)
    manhattan_inertia = 0.0
    for c in range(k):
        mask = labels_man == c
        if np.sum(mask) > 0:
            center = np.median(scaled_data[mask], axis=0)
            manhattan_inertia += np.sum(np.abs(scaled_data[mask] - center))
    
    return {
        'euclidean': {
            'silhouette': sil_euc,
            'davies_bouldin': db_euc,
            'inertia': wcss_euc,
            'labels': labels_euc.tolist(),
        },
        'manhattan': {
            'silhouette': sil_man,
            'inertia': float(manhattan_inertia),
            'labels': labels_man.tolist(),
        },
    }


def _kmedians(X: np.ndarray, k: int, max_iter: int = 100, random_state: int = 42) -> np.ndarray:
    """Simple K-Medians implementation using Manhattan distance."""
    rng = np.random.RandomState(random_state)
    n = X.shape[0]
    
    # Random initialization
    idx = rng.choice(n, k, replace=False)
    centers = X[idx].copy()
    
    for _ in range(max_iter):
        # Assign labels using Manhattan distance
        dists = cdist(X, centers, metric='cityblock')
        labels = np.argmin(dists, axis=1)
        
        # Update centers as component-wise medians
        new_centers = np.zeros_like(centers)
        for c in range(k):
            mask = labels == c
            if np.sum(mask) > 0:
                new_centers[c] = np.median(X[mask], axis=0)
            else:
                new_centers[c] = centers[c]
        
        if np.allclose(centers, new_centers):
            break
        centers = new_centers
    
    return labels


def run_hierarchical_clustering(
    scaled_data: np.ndarray,
    n_clusters: int = 4,
    sample_size: int = 500,
) -> Dict[str, Any]:
    """
    Run hierarchical (agglomerative) clustering and generate dendrogram data.
    Uses a sample for dendrogram visualization to avoid overplotting.
    """
    # Full dataset clustering
    agg = AgglomerativeClustering(n_clusters=n_clusters, linkage='ward')
    labels = agg.fit_predict(scaled_data)
    
    sil = float(silhouette_score(scaled_data, labels))
    db = float(davies_bouldin_score(scaled_data, labels))
    
    # Dendrogram data on a sample
    rng = np.random.RandomState(42)
    sample_idx = rng.choice(len(scaled_data), min(sample_size, len(scaled_data)), replace=False)
    sample_data = scaled_data[sample_idx]
    
    Z = linkage(sample_data, method='ward')
    
    # Extract dendrogram structure for JSON
    dendro_data = _extract_dendrogram_data(Z, sample_size=len(sample_idx))
    
    # Cluster sizes
    cluster_sizes = {}
    for c in range(n_clusters):
        cluster_sizes[str(c)] = int(np.sum(labels == c))
    
    return {
        'labels': labels.tolist(),
        'silhouette_score': sil,
        'davies_bouldin_score': db,
        'cluster_sizes': cluster_sizes,
        'dendrogram': dendro_data,
        'linkage_method': 'ward',
        'n_clusters': n_clusters,
    }


def _extract_dendrogram_data(Z: np.ndarray, sample_size: int) -> Dict[str, Any]:
    """Convert linkage matrix to JSON-serializable dendrogram data."""
    merges = []
    for i, row in enumerate(Z):
        merges.append({
            'cluster1': int(row[0]),
            'cluster2': int(row[1]),
            'distance': float(row[2]),
            'size': int(row[3]),
        })
    
    # Last N merge distances for visualization
    distances = Z[:, 2].tolist()
    
    return {
        'merges': merges[-30:],  # Last 30 merges for viz
        'distances': distances,
        'n_samples': sample_size,
    }


def build_cluster_profiles(
    df: pd.DataFrame,
    labels: np.ndarray,
    feature_names: List[str],
) -> Dict[str, Any]:
    """
    Build interpretable profiles for each cluster.
    Computes mean, median, std for each feature per cluster.
    """
    df_work = df[feature_names].copy()
    df_work['cluster'] = labels
    
    profiles = {}
    n_clusters = len(set(labels))
    
    for c in range(n_clusters):
        cluster_data = df_work[df_work['cluster'] == c]
        profile = {}
        
        for feat in feature_names:
            vals = cluster_data[feat].dropna()
            profile[feat] = {
                'mean': round(float(vals.mean()), 3),
                'median': round(float(vals.median()), 3),
                'std': round(float(vals.std()), 3),
                'min': round(float(vals.min()), 3),
                'max': round(float(vals.max()), 3),
            }
        
        profiles[str(c)] = {
            'size': int(len(cluster_data)),
            'percentage': round(len(cluster_data) / len(df_work) * 100, 1),
            'features': profile,
        }
    
    # Overall stats for comparison
    overall = {}
    for feat in feature_names:
        vals = df_work[feat].dropna()
        overall[feat] = {
            'mean': round(float(vals.mean()), 3),
            'std': round(float(vals.std()), 3),
        }
    
    # Cluster interpretation based on key features
    interpretations = _interpret_clusters(profiles, feature_names)
    
    return {
        'profiles': profiles,
        'overall': overall,
        'interpretations': interpretations,
        'radar_data': _build_radar_data(profiles, overall, feature_names),
    }


def _interpret_clusters(
    profiles: Dict, feature_names: List[str]
) -> Dict[str, str]:
    """Generate human-readable interpretations of clusters."""
    interpretations = {}
    
    key_features = [
        'delay_days', 'dispute_flag', 'num_owners', 'consent_obtained_pct',
        'digitization_level', 'objections_filed', 'mutation_pending',
    ]
    
    cluster_names = [
        'Swift Acquisition', 'Procedural Delays', 'Disputed & Complex',
        'Severely Stalled', 'Moderate Friction', 'Rural Transition',
        'High-Value Urban',
    ]
    
    for c_key, profile in profiles.items():
        c = int(c_key)
        feats = profile['features']
        
        descriptors = []
        
        delay = feats.get('delay_days', {}).get('mean', 0)
        if delay < 50:
            descriptors.append('low delay')
        elif delay < 120:
            descriptors.append('moderate delay')
        else:
            descriptors.append('high delay')
        
        if feats.get('dispute_flag', {}).get('mean', 0) > 0.3:
            descriptors.append('high dispute rate')
        
        if feats.get('consent_obtained_pct', {}).get('mean', 0) > 75:
            descriptors.append('good consent levels')
        elif feats.get('consent_obtained_pct', {}).get('mean', 0) < 50:
            descriptors.append('low consent')
        
        if feats.get('digitization_level', {}).get('mean', 0) > 70:
            descriptors.append('well-digitized')
        
        if feats.get('num_owners', {}).get('mean', 0) > 5:
            descriptors.append('multi-owner')
        
        name = cluster_names[c] if c < len(cluster_names) else f'Cluster {c}'
        interpretations[c_key] = {
            'name': name,
            'description': f'{name}: {", ".join(descriptors)}',
            'key_traits': descriptors,
        }
    
    return interpretations


def _build_radar_data(
    profiles: Dict, overall: Dict, feature_names: List[str]
) -> List[Dict]:
    """Build radar/spider chart data for cluster comparison."""
    # Normalize features to 0-1 scale relative to overall stats
    radar_features = [
        'delay_days', 'dispute_flag', 'num_owners', 'consent_obtained_pct',
        'digitization_level', 'objections_filed', 'area_hectares',
        'compensation_offered_lakh', 'rehabilitation_score',
    ]
    
    radar_data = []
    for feat in radar_features:
        if feat not in overall:
            continue
        entry = {'feature': feat}
        overall_mean = overall[feat]['mean']
        overall_std = max(overall[feat]['std'], 0.001)
        
        for c_key, profile in profiles.items():
            if feat in profile['features']:
                # Normalized score (z-score mapped to 0-1)
                z = (profile['features'][feat]['mean'] - overall_mean) / overall_std
                normalized = max(0, min(1, (z + 2) / 4))  # Map [-2,2] to [0,1]
                entry[f'cluster_{c_key}'] = round(normalized, 3)
        
        radar_data.append(entry)
    
    return radar_data


def run_full_pipeline(n_samples: int = 2000) -> Dict[str, Any]:
    """
    Execute the complete clustering analysis pipeline.
    Returns all results as a JSON-serializable dictionary.
    """
    from .data_generator import generate_land_acquisition_dataset, get_feature_descriptions
    
    # 1. Generate data
    df = generate_land_acquisition_dataset(n_samples=n_samples)
    
    # 2. Preprocess
    scaled_data, cleaned_df, scaler = preprocess_data(df)
    
    # 3. PCA
    pca_results = run_pca(scaled_data)
    
    # 4. K-Means analysis
    kmeans_results = run_kmeans_analysis(scaled_data, k_values=[3, 4, 5, 6, 7])
    
    # 5. Distance metric comparison
    distance_comparison = compare_distance_metrics(scaled_data, k=4)
    
    # 6. Hierarchical clustering
    hierarchical_results = run_hierarchical_clustering(scaled_data, n_clusters=4)
    
    # 7. Determine best k (by silhouette score)
    best_k = max(kmeans_results.keys(),
                 key=lambda k: kmeans_results[k]['silhouette_score'])
    best_labels = np.array(kmeans_results[best_k]['labels'])
    
    # 8. Cluster profiles
    profiles = build_cluster_profiles(cleaned_df, best_labels, CLUSTERING_FEATURES)
    
    # 9. Dataset summary
    dataset_summary = {
        'n_samples': len(df),
        'n_features': len(CLUSTERING_FEATURES),
        'features': CLUSTERING_FEATURES,
        'feature_descriptions': get_feature_descriptions(),
        'missing_values': df[CLUSTERING_FEATURES].isnull().sum().to_dict(),
        'basic_stats': {},
    }
    
    for col in CLUSTERING_FEATURES:
        vals = df[col].dropna()
        dataset_summary['basic_stats'][col] = {
            'mean': round(float(vals.mean()), 3),
            'std': round(float(vals.std()), 3),
            'min': round(float(vals.min()), 3),
            'max': round(float(vals.max()), 3),
            'median': round(float(vals.median()), 3),
        }
    
    # 10. Compile PCA + labels for scatter
    pca_scatter = []
    pca_2d = pca_results['pca_data_2d']
    for i in range(len(pca_2d)):
        point = {
            'x': round(pca_2d[i][0], 4),
            'y': round(pca_2d[i][1], 4),
            'cluster': int(best_labels[i]),
        }
        # Add 3D if available
        if pca_results['pca_data_3d']:
            point['z'] = round(pca_results['pca_data_3d'][i][2], 4)
        pca_scatter.append(point)
    
    # Elbow data
    elbow_data = []
    for k_key, res in sorted(kmeans_results.items(), key=lambda x: int(x[0])):
        elbow_data.append({
            'k': int(k_key),
            'wcss': res['wcss'],
            'silhouette': res['silhouette_score'],
            'davies_bouldin': res['davies_bouldin_score'],
            'calinski_harabasz': res['calinski_harabasz_score'],
        })
    
    return {
        'dataset_summary': dataset_summary,
        'pca': pca_results,
        'pca_scatter': pca_scatter,  # Sampled for frontend
        'kmeans': kmeans_results,
        'elbow_data': elbow_data,
        'distance_comparison': distance_comparison,
        'hierarchical': hierarchical_results,
        'best_k': int(best_k),
        'profiles': profiles,
        'limitations': _get_limitations(),
        'ethical_considerations': _get_ethical_considerations(),
    }


def _get_limitations() -> List[Dict[str, str]]:
    """Document analysis limitations."""
    return [
        {
            'title': 'Synthetic Data',
            'description': 'This analysis uses synthetically generated data modeled after DILRMP patterns. Real-world data may exhibit different distributions, correlations, and anomalies.',
        },
        {
            'title': 'Feature Selection Bias',
            'description': 'The 17 features selected may not capture all factors influencing acquisition delays. Important variables like political context, seasonal effects, or infrastructure proximity are not modeled.',
        },
        {
            'title': 'Sampling Bias',
            'description': 'The synthetic generation uses uniform state sampling. Actual DILRMP data may be skewed toward states with more digitized records, underrepresenting regions with poor data infrastructure.',
        },
        {
            'title': 'Cluster Stability',
            'description': 'K-Means results depend on initialization and may vary across runs. While k-means++ initialization and multiple restarts mitigate this, the optimal k remains a judgment call.',
        },
        {
            'title': 'Scaling Assumptions',
            'description': 'StandardScaler assumes features are roughly Gaussian. Highly skewed features (e.g., compensation_offered_lakh) may distort distance calculations.',
        },
        {
            'title': 'Temporal Dynamics',
            'description': 'The snapshot-based analysis does not capture how delay patterns evolve over time or respond to policy changes.',
        },
    ]


def _get_ethical_considerations() -> List[Dict[str, str]]:
    """Document ethical considerations for responsible use."""
    return [
        {
            'title': 'Potential for Discriminatory Application',
            'description': 'Clustering results should not be used to deny or delay services to specific communities or regions. Identified "high delay" clusters may reflect systemic inequities rather than negligence.',
        },
        {
            'title': 'Privacy and Consent',
            'description': 'Real DILRMP data contains personally identifiable information of landowners. Any deployment must comply with data protection regulations and ensure adequate anonymization.',
        },
        {
            'title': 'Stakeholder Impact',
            'description': 'Land acquisition directly affects livelihoods. Cluster-based policy decisions must consider the human impact and not reduce affected communities to data points.',
        },
        {
            'title': 'Transparency and Accountability',
            'description': 'The methodology, assumptions, and limitations should be fully disclosed to all stakeholders. Decision-makers must understand that cluster assignments are probabilistic, not deterministic.',
        },
        {
            'title': 'Avoiding Automation Bias',
            'description': 'These clusters should inform, not replace, human judgment. Officials should not blindly follow cluster-based recommendations without contextual understanding.',
        },
        {
            'title': 'Equitable Resource Allocation',
            'description': 'If used for resource allocation, care must be taken to ensure that historically marginalized communities receive equitable attention regardless of cluster assignment.',
        },
    ]
