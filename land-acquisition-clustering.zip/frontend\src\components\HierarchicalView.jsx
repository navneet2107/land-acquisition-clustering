import React from 'react';
import { motion } from 'framer-motion';

export default function HierarchicalView({ data }) {
  if (!data) return null;

  return (
    <section className="section" id="hierarchical">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">Step 6</span>
        <h2>Hierarchical Clustering</h2>
        <p className="subtitle">
          Agglomerative clustering with Ward linkage for comparison against K-Means.
          Evaluated at k = {data.n_clusters} clusters with Silhouette and Davies-Bouldin metrics.
        </p>
      </motion.div>

      <div className="grid-3">
        <motion.div
          className="glass-card metric-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="metric-value">{data.silhouette_score?.toFixed(4)}</div>
          <div className="metric-label">Silhouette Score</div>
        </motion.div>
        <motion.div
          className="glass-card metric-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
        >
          <div className="metric-value">{data.davies_bouldin_score?.toFixed(4)}</div>
          <div className="metric-label">Davies-Bouldin Index</div>
        </motion.div>
        <motion.div
          className="glass-card metric-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        >
          <div className="metric-value" style={{ textTransform: 'capitalize' }}>{data.linkage_method}</div>
          <div className="metric-label">Linkage Method</div>
        </motion.div>
      </div>

      {/* Cluster sizes */}
      {data.cluster_sizes && (
        <motion.div
          className="glass-card"
          style={{ marginTop: 32 }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 style={{ color: 'var(--purple-300)', marginBottom: 20, fontSize: '1rem' }}>
            Hierarchical Cluster Sizes
          </h3>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            {Object.entries(data.cluster_sizes).map(([c, size]) => {
              const total = Object.values(data.cluster_sizes).reduce((a, b) => a + b, 0);
              const pct = ((size / total) * 100).toFixed(1);
              const colors = ['#22d3ee', '#a855f7', '#f59e0b', '#ef4444'];
              const color = colors[parseInt(c) % colors.length];

              return (
                <div
                  key={c}
                  style={{
                    flex: 1,
                    minWidth: 150,
                    padding: 20,
                    background: `${color}10`,
                    border: `1px solid ${color}30`,
                    borderRadius: 14,
                    textAlign: 'center',
                  }}
                >
                  <div style={{ fontSize: '1.4rem', fontWeight: 700, color }}>{size}</div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 4 }}>
                    Cluster {c} ({pct}%)
                  </div>
                </div>
              );
            })}
          </div>

          {/* Comparison note */}
          <div style={{
            marginTop: 24,
            padding: '16px 20px',
            background: 'rgba(120, 80, 220, 0.08)',
            borderRadius: 12,
            border: '1px solid rgba(120, 80, 220, 0.15)',
          }}>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', lineHeight: 1.6 }}>
              <strong style={{ color: 'var(--purple-300)' }}>K-Means vs Hierarchical: </strong>
              Ward linkage agglomerative clustering produces similar cluster structures to K-Means
              as both minimize within-cluster variance. Hierarchical clustering additionally provides
              a dendrogram view of the merge sequence, which can reveal sub-cluster structure that
              flat partitioning methods miss.
            </p>
          </div>
        </motion.div>
      )}

      {/* Dendrogram placeholder with merge distance info */}
      {data.dendrogram && (
        <motion.div
          className="glass-card"
          style={{ marginTop: 24 }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 style={{ color: 'var(--purple-300)', marginBottom: 16, fontSize: '1rem' }}>
            Dendrogram — Last Merge Distances
          </h3>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height: 200, padding: '0 10px' }}>
            {(data.dendrogram.distances || []).slice(-40).map((d, i) => {
              const maxD = Math.max(...data.dendrogram.distances.slice(-40));
              const h = (d / maxD) * 180;
              return (
                <div
                  key={i}
                  style={{
                    flex: 1,
                    height: h,
                    minHeight: 2,
                    background: `linear-gradient(180deg, #a855f7, #7c3aed${
                      h > 100 ? '' : '60'
                    })`,
                    borderRadius: '3px 3px 0 0',
                    transition: 'height 0.5s',
                  }}
                  title={`Merge distance: ${d.toFixed(2)}`}
                />
              );
            })}
          </div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 10, textAlign: 'center' }}>
            Merge distance progression (last {Math.min(40, (data.dendrogram.distances || []).length)} merges) —
            large jumps indicate natural cluster boundaries
          </p>
        </motion.div>
      )}
    </section>
  );
}
