@echo off
echo ========================================================
echo Starting LACPS React + Vite + Three.js Frontend Server...
echo ========================================================
cd /d %~dp0frontend
echo Installing npm packages...
npm install
echo Starting Vite Dev Server on http://localhost:5173
npm run dev
pause
