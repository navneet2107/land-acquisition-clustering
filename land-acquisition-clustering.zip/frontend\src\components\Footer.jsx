import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-brand">LACPS</div>
      <p className="footer-text">
        Land Acquisition Delay Pattern Segmentation Using Clustering Methods
        <br />
        Smart India Hackathon 2026 • SIH26017 • CO2, CO3, CO5
        <br />
        Unit II, III &amp; IV — Partition Clustering, Hierarchical Comparison, PCA Visualisation
      </p>
      <div className="footer-links">
        <a href="#overview">Data Overview</a>
        <a href="#clustering">Clustering</a>
        <a href="#pca">PCA</a>
        <a href="#metrics">Metrics</a>
        <a href="#profiles">Profiles</a>
        <a href="#limitations">Ethics &amp; Limitations</a>
      </div>
      <p className="footer-text" style={{ marginTop: 32, opacity: 0.5, fontSize: '0.75rem' }}>
        © 2026 LACPS Research. Built with FastAPI, scikit-learn, React &amp; Three.js
      </p>
    </footer>
  );
}
