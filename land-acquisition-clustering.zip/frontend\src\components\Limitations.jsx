import React from 'react';
import { motion } from 'framer-motion';

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.1 } },
};
const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

export default function Limitations({ limitations, ethical }) {
  return (
    <section className="section" id="limitations">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">Step 8</span>
        <h2>Limitations & Ethical Considerations</h2>
        <p className="subtitle">
          Responsible AI requires transparency about methodology limitations,
          potential biases, and ethical implications of clustering-based decisions
          in land acquisition contexts.
        </p>
      </motion.div>

      <div className="grid-2">
        {/* Limitations */}
        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >
          <h3 style={{
            color: 'var(--cluster-2)', marginBottom: 20, fontSize: '1.1rem',
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            ⚠️ Methodological Limitations
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {(limitations || []).map((lim, i) => (
              <motion.div className="glass-card limitation-card warning" key={i} variants={item}>
                <h4>{lim.title}</h4>
                <p>{lim.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Ethical considerations */}
        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >
          <h3 style={{
            color: 'var(--cluster-3)', marginBottom: 20, fontSize: '1.1rem',
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            🛡️ Ethical Considerations
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {(ethical || []).map((eth, i) => (
              <motion.div className="glass-card limitation-card ethical" key={i} variants={item}>
                <h4>{eth.title}</h4>
                <p>{eth.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Responsible use summary */}
      <motion.div
        className="glass-card"
        style={{
          marginTop: 40,
          background: 'linear-gradient(135deg, rgba(120, 80, 220, 0.12), rgba(34, 211, 238, 0.06))',
          borderColor: 'rgba(120, 80, 220, 0.3)',
        }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <h3 style={{ color: 'var(--purple-300)', marginBottom: 16, fontSize: '1.1rem' }}>
          📋 Responsible Use Guidelines
        </h3>
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: 16,
        }}>
          {[
            {
              icon: '🎯',
              title: 'Use as Decision Support',
              text: 'Cluster assignments should supplement — not replace — expert judgment in land acquisition policy.',
            },
            {
              icon: '🔍',
              title: 'Validate with Domain Experts',
              text: 'All discovered patterns must be reviewed by land administration professionals before informing policy.',
            },
            {
              icon: '📊',
              title: 'Monitor for Drift',
              text: 'Regularly re-evaluate cluster structures as new data arrives; patterns may shift with policy changes.',
            },
            {
              icon: '⚖️',
              title: 'Ensure Equity',
              text: 'Verify that cluster-based resource allocation does not systematically disadvantage vulnerable communities.',
            },
          ].map(({ icon, title, text }) => (
            <div
              key={title}
              style={{
                padding: 16,
                background: 'rgba(10, 10, 26, 0.5)',
                borderRadius: 12,
                border: '1px solid rgba(120, 80, 220, 0.15)',
              }}
            >
              <div style={{ fontSize: '1.5rem', marginBottom: 8 }}>{icon}</div>
              <h4 style={{ color: 'var(--text-primary)', fontSize: '0.95rem', marginBottom: 6 }}>
                {title}
              </h4>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', lineHeight: 1.6 }}>
                {text}
              </p>
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
