import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sparkles, OrbitControls } from '@react-three/drei';
import { EffectComposer, Bloom } from '@react-three/postprocessing';
import { motion } from 'framer-motion';
import * as THREE from 'three';

/* ── Organic Sphere (AOVIX-style blob) ── */
function OrganicSphere() {
  const meshRef = useRef();

  useFrame(({ clock }) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = clock.getElapsedTime() * 0.08;
      meshRef.current.rotation.x = Math.sin(clock.getElapsedTime() * 0.05) * 0.1;
    }
  });

  return (
    <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.5}>
      <mesh ref={meshRef} scale={2.2}>
        <icosahedronGeometry args={[1, 12]} />
        <MeshDistortMaterial
          color="#6d28d9"
          emissive="#3b0764"
          emissiveIntensity={0.5}
          roughness={0.3}
          metalness={0.8}
          distort={0.4}
          speed={2}
        />
      </mesh>
    </Float>
  );
}

/* ── Particle Ring ── */
function ParticleRing() {
  const ref = useRef();
  const count = 500;

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const radius = 3 + Math.random() * 0.5;
      pos[i * 3] = Math.cos(angle) * radius;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 0.8;
      pos[i * 3 + 2] = Math.sin(angle) * radius;
    }
    return pos;
  }, []);

  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.y = clock.getElapsedTime() * 0.05;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.03}
        color="#a855f7"
        transparent
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  );
}

/* ── Data Points Cloud (representing clusters) ── */
function DataCloud() {
  const ref = useRef();
  const count = 300;

  const { positions, colors } = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const clusterColors = [
      new THREE.Color('#22d3ee'),
      new THREE.Color('#a855f7'),
      new THREE.Color('#f59e0b'),
      new THREE.Color('#ef4444'),
    ];

    for (let i = 0; i < count; i++) {
      const cluster = i % 4;
      const cx = [-1.5, 1.5, -0.5, 2][cluster];
      const cy = [0.5, -0.5, -1.5, 1][cluster];
      const cz = [0.5, -0.5, 0.5, -1][cluster];

      pos[i * 3] = cx + (Math.random() - 0.5) * 1.2;
      pos[i * 3 + 1] = cy + (Math.random() - 0.5) * 1.2;
      pos[i * 3 + 2] = cz + (Math.random() - 0.5) * 1.2;

      const c = clusterColors[cluster];
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;
    }
    return { positions: pos, colors: col };
  }, []);

  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.y = clock.getElapsedTime() * 0.03;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
        <bufferAttribute attach="attributes-color" count={count} array={colors} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial size={0.06} vertexColors transparent opacity={0.8} sizeAttenuation />
    </points>
  );
}

/* ── Scene ── */
function Scene() {
  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[5, 5, 5]} intensity={1} color="#7c3aed" />
      <pointLight position={[-5, -3, 3]} intensity={0.5} color="#22d3ee" />
      <pointLight position={[0, 3, -5]} intensity={0.3} color="#a855f7" />

      <OrganicSphere />
      <ParticleRing />
      <DataCloud />
      <Sparkles count={200} scale={8} size={1.5} speed={0.3} color="#c084fc" opacity={0.5} />

      <OrbitControls
        enableZoom={false}
        enablePan={false}
        autoRotate
        autoRotateSpeed={0.3}
        maxPolarAngle={Math.PI / 1.8}
        minPolarAngle={Math.PI / 3}
      />

      <EffectComposer>
        <Bloom luminanceThreshold={0.3} luminanceSmoothing={0.9} intensity={0.8} />
      </EffectComposer>
    </>
  );
}

/* ── Hero Component ── */
export default function Hero({ onAnalyze, loading, hasData }) {
  return (
    <section className="hero" id="hero">
      {/* Background glow */}
      <div className="hero-bg-glow" style={{ top: '30%', left: '50%' }} />

      {/* Large background text */}
      <motion.div
        className="hero-title-bg"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2, delay: 0.5 }}
      >
        LACPS
      </motion.div>

      {/* 3D Globe */}
      <div className="globe-container">
        <Canvas camera={{ position: [0, 0, 6], fov: 55 }}>
          <Scene />
        </Canvas>
      </div>

      {/* Floating AOVIX-style cards */}
      <motion.div
        className="floating-card animate-float"
        style={{ top: '32%', left: '18%' }}
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1, duration: 0.8 }}
      >
        <div className="fc-label">K-MEANS</div>
        <div className="fc-value">k = 3, 4, 5, 6, 7</div>
      </motion.div>

      <motion.div
        className="floating-card animate-float-delay"
        style={{ top: '28%', right: '16%' }}
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.2, duration: 0.8 }}
      >
        <div className="fc-label">PCA</div>
        <div className="fc-value">3-Component Analysis</div>
      </motion.div>

      <motion.div
        className="floating-card animate-float"
        style={{ bottom: '28%', left: '15%' }}
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.4, duration: 0.8 }}
      >
        <div className="fc-label">DILRMP</div>
        <div className="fc-value">Land Record Analytics</div>
      </motion.div>

      <motion.div
        className="floating-card animate-float-delay"
        style={{ bottom: '25%', right: '18%' }}
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.6, duration: 0.8 }}
      >
        <div className="fc-label">SILHOUETTE</div>
        <div className="fc-value">Cluster Validation</div>
      </motion.div>

      {/* Main content */}
      <motion.div
        className="hero-content"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 0.3 }}
      >
        <div className="hero-badges">
          <span className="hero-badge">SIH 2026</span>
          <span className="hero-badge">SIH26017</span>
          <span className="hero-badge">CO2 • CO3 • CO5</span>
          <span className="hero-badge">Unsupervised ML</span>
        </div>

        <h1>Land Acquisition Delay Pattern Segmentation</h1>

        <p>
          Advanced clustering analysis of DILRMP land acquisition records using
          K-Means, hierarchical comparison, and PCA visualization to identify
          delay patterns and support data-driven policy decisions.
        </p>

        <div className="hero-actions">
          <button className="btn-primary" onClick={onAnalyze} disabled={loading}>
            {loading ? '⏳ Processing…' : hasData ? '🔄 Re-run Analysis' : '🚀 Launch Analysis'}
          </button>
          <a href="#overview" className="btn-outline">
            Explore Results ↓
          </a>
        </div>

        <div className="hero-stats">
          <div className="hero-stat">
            <div className="value">2,000</div>
            <div className="label">Records Analyzed</div>
          </div>
          <div className="hero-stat">
            <div className="value">17</div>
            <div className="label">Features Extracted</div>
          </div>
          <div className="hero-stat">
            <div className="value">5</div>
            <div className="label">K Configurations</div>
          </div>
          <div className="hero-stat">
            <div className="value">3</div>
            <div className="label">Validation Metrics</div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
