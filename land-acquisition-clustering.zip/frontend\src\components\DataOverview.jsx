import React from 'react';
import { motion } from 'framer-motion';

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

export default function DataOverview({ data }) {
  if (!data) return null;

  const missingCols = Object.entries(data.missing_values || {}).filter(([, v]) => v > 0);

  return (
    <section className="section" id="overview">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <span className="section-tag">Step 1</span>
        <h2>Dataset Overview</h2>
        <p className="subtitle">
          Synthetic DILRMP land acquisition dataset with {data.n_samples} records
          and {data.n_features} clustering features, preprocessed with median imputation
          and StandardScaler normalization.
        </p>
      </motion.div>

      {/* Top metrics */}
      <motion.div
        className="grid-4"
        variants={container}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true }}
      >
        <motion.div className="glass-card metric-card" variants={item}>
          <div className="metric-value">{data.n_samples?.toLocaleString()}</div>
          <div className="metric-label">Total Records</div>
        </motion.div>
        <motion.div className="glass-card metric-card" variants={item}>
          <div className="metric-value">{data.n_features}</div>
          <div className="metric-label">Clustering Features</div>
        </motion.div>
        <motion.div className="glass-card metric-card" variants={item}>
          <div className="metric-value">{missingCols.length}</div>
          <div className="metric-label">Columns with Missing</div>
        </motion.div>
        <motion.div className="glass-card metric-card" variants={item}>
          <div className="metric-value">Median</div>
          <div className="metric-label">Imputation Strategy</div>
        </motion.div>
      </motion.div>

      {/* Feature table */}
      <motion.div
        className="glass-card"
        style={{ marginTop: 32, overflowX: 'auto' }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <h3 style={{ marginBottom: 20, color: 'var(--purple-300)', fontSize: '1.1rem' }}>
          Feature Statistics
        </h3>
        <table className="comparison-table">
          <thead>
            <tr>
              <th>Feature</th>
              <th>Mean</th>
              <th>Std</th>
              <th>Min</th>
              <th>Median</th>
              <th>Max</th>
              <th>Missing</th>
            </tr>
          </thead>
          <tbody>
            {data.features?.map((feat) => {
              const stats = data.basic_stats?.[feat] || {};
              const missing = data.missing_values?.[feat] || 0;
              return (
                <tr key={feat}>
                  <td style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{feat}</td>
                  <td>{stats.mean?.toFixed(2)}</td>
                  <td>{stats.std?.toFixed(2)}</td>
                  <td>{stats.min?.toFixed(2)}</td>
                  <td>{stats.median?.toFixed(2)}</td>
                  <td>{stats.max?.toFixed(2)}</td>
                  <td className={missing > 0 ? 'highlight-cell' : ''}>{missing}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </motion.div>

      {/* Missing values summary */}
      {missingCols.length > 0 && (
        <motion.div
          className="glass-card"
          style={{ marginTop: 24 }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 style={{ marginBottom: 16, color: 'var(--purple-300)', fontSize: '1rem' }}>
            Missing Value Treatment
          </h3>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
            {missingCols.map(([col, count]) => (
              <div
                key={col}
                style={{
                  padding: '8px 16px',
                  background: 'rgba(245, 158, 11, 0.1)',
                  border: '1px solid rgba(245, 158, 11, 0.3)',
                  borderRadius: 10,
                  fontSize: '0.8rem',
                }}
              >
                <span style={{ color: 'var(--text-primary)', fontWeight: 600 }}>{col}</span>
                <span style={{ color: 'var(--text-muted)', marginLeft: 8 }}>{count} missing → median imputed</span>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </section>
  );
}
